Hello World! (WAR-style)
===============
Checking Push to Remote Repository in GitHub. Testing software
This is the simplest possible Java webapp for testing servlet container deployments.  It should work on any container and requires no other dependencies or configuration.
